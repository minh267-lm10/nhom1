# nhac

# Install Kafka
`docker-compose up -d`
# Đầu mục phải làm
`làm playlist và song`
`lầm thư viện cá nhân`
`làm file service`
`làm post cho ARTIST`
`làm follow view líke`
`lầm báo cáo cho ARTIST `
`làm xử lí thanh toán`
`làm search service`

